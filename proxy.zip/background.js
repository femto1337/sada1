var config = {
  mode: "fixed_servers",
  rules: {
    singleProxy: {
      host: "188.130.136.244",
      port: parseInt(5500)
    }
  }
};

chrome.proxy.settings.set({
  value: config,
  scope: "regular"
}, function() {});

function callbackFunc(details) {
  return {
    authCredentials: {
      username: "OQRYcE",
      password: "kquxwncB9r"
    }
  };
}

chrome.webRequest.onAuthRequired.addListener(
  callbackFunc, {
    urls: ["<all_urls>"]
  },
  ['blocking']
);